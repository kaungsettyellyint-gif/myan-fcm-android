# Keep the FCM service entry point.
-keep class app.base44.myan_copy_c4c14eb9.twa.MyFirebaseMessagingService { *; }
