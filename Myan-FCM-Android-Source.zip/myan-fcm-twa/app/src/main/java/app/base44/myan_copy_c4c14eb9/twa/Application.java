package app.base44.myan_copy_c4c14eb9.twa;

public class Application extends android.app.Application { }
