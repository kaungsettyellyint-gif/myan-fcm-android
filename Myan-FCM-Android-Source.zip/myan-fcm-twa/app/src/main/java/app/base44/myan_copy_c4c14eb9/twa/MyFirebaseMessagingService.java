package app.base44.myan_copy_c4c14eb9.twa;

import android.content.Intent;
import android.content.SharedPreferences;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.os.Build;
import androidx.core.app.NotificationCompat;
import com.google.firebase.messaging.RemoteMessage;
import com.google.firebase.messaging.FirebaseMessagingService;

public class MyFirebaseMessagingService extends FirebaseMessagingService {
    public static final String PREFS = "fcm_bridge";
    public static final String KEY_TOKEN = "token";
    public static final String ACTION_TOKEN = "app.base44.myan_copy_c4c14eb9.twa.FCM_TOKEN_UPDATED";

    @Override public void onNewToken(String token) {
        saveAndBroadcast(token);
    }

    @Override public void onMessageReceived(RemoteMessage message) {
        RemoteMessage.Notification n = message.getNotification();
        String title = n != null && n.getTitle() != null ? n.getTitle() : "Myan+";
        String body = n != null && n.getBody() != null ? n.getBody() : "You have a new notification";
        showNotification(title, body);
    }

    private void showNotification(String title, String body) {
        final String channelId = "myan_fcm";
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (Build.VERSION.SDK_INT >= 26) {
            nm.createNotificationChannel(new NotificationChannel(channelId, "Myan+ Notifications", NotificationManager.IMPORTANCE_HIGH));
        }
        Intent launch = new Intent(this, LauncherActivity.class);
        launch.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 9001, launch, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationCompat.Builder b = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(body)
                .setAutoCancel(true)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setContentIntent(pi);
        nm.notify((int) System.currentTimeMillis(), b.build());
    }

    private void saveAndBroadcast(String token) {
        getSharedPreferences(PREFS, MODE_PRIVATE).edit().putString(KEY_TOKEN, token).apply();
        Intent i = new Intent(ACTION_TOKEN);
        i.setPackage(getPackageName());
        i.putExtra(KEY_TOKEN, token);
        sendBroadcast(i);
    }
}
