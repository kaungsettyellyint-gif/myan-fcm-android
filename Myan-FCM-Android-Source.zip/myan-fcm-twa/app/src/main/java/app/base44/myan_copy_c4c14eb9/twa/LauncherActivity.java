package app.base44.myan_copy_c4c14eb9.twa;

import android.Manifest;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.browser.customtabs.CustomTabsCallback;
import androidx.browser.customtabs.CustomTabsSession;
import androidx.core.content.ContextCompat;

import com.google.androidbrowserhelper.trusted.LauncherActivity;

import org.json.JSONObject;

public class LauncherActivity extends com.google.androidbrowserhelper.trusted.LauncherActivity {
    private static final String ORIGIN = "https://myan-copy-c4c14eb9.base44.app";
    private BroadcastReceiver tokenReceiver;
    private boolean channelReady = false;

    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        if (Build.VERSION.SDK_INT >= 33 && ContextCompat.checkSelfPermission(this, Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 7001);
        }
        tokenReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (ACTION_TOKEN.equals(intent.getAction())) sendStoredToken();
            }
        };
        IntentFilter f = new IntentFilter(ACTION_TOKEN);
        ContextCompat.registerReceiver(this, tokenReceiver, f, ContextCompat.RECEIVER_NOT_EXPORTED);
    }

    private static final String ACTION_TOKEN = MyFirebaseMessagingService.ACTION_TOKEN;

    @Override
    protected void onDestroy() {
        if (tokenReceiver != null) unregisterReceiver(tokenReceiver);
        super.onDestroy();
    }

    @Override
    protected CustomTabsCallback getCustomTabsCallback() {
        return new CustomTabsCallback() {
            @Override public void onNavigationEvent(int navigationEvent, Bundle extras) {
                if (navigationEvent != NAVIGATION_FINISHED) return;
                CustomTabsSession session = getCustomTabsSession();
                if (session != null) session.requestPostMessageChannel(android.net.Uri.parse(ORIGIN), android.net.Uri.parse(ORIGIN), new Bundle());
            }
            @Override public void onMessageChannelReady(@Nullable Bundle extras) {
                channelReady = true;
                sendStoredToken();
            }
        };
    }

    private void sendStoredToken() {
        if (!channelReady) return;
        CustomTabsSession session = getCustomTabsSession();
        if (session == null) return;
        SharedPreferences p = getSharedPreferences(MyFirebaseMessagingService.PREFS, MODE_PRIVATE);
        String token = p.getString(MyFirebaseMessagingService.KEY_TOKEN, null);
        if (token == null || token.isEmpty()) return;
        try {
            JSONObject obj = new JSONObject();
            obj.put("type", "FCM_TOKEN");
            obj.put("token", token);
            obj.put("fcmToken", token);
            session.postMessage(obj.toString(), null);
        } catch (Exception ignored) { }
    }
}
