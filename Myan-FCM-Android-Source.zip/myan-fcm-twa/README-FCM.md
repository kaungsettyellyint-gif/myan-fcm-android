# Myan+ FCM TWA source project

Package ID: app.base44.myan_copy_c4c14eb9.twa
Existing version: 1.3.1.0 / versionCode 5
Prepared update: 1.3.2.0 / versionCode 6

This project keeps the PWA as a Trusted Web Activity and adds native Firebase Cloud Messaging. The native FCM service stores the registration token and sends it to the PWA over the TWA postMessage channel as JSON with `type: FCM_TOKEN`, `token`, and `fcmToken` fields.

Firebase configuration is in app/google-services.json.

Do NOT commit signing.keystore or passwords to source control. Use the existing signing.keystore separately when producing the Play Store release.

The existing Play Store signing/upload keystore fingerprint is:
B0:89:C0:24:92:3D:E9:27:A0:D8:11:2F:CA:19:AA:09:39:FF:1A:27:88:E6:2E:EB:7D:F3:7C:82:FD:D4:93:F4

Build with Android Studio after installing Android SDK/Build Tools. Use versionCode 6 or higher for the Play Store update.
